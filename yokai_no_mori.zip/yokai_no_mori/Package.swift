// swift-tools-version:4.2
// The swift-tools-version declares the minimum version of Swift required to build this package.

import PackageDescription

let package = Package(
    name: "yokai_no_mori",
    products: [
        // Products define the executables and libraries produced by a package, and make them visible to other packages.
        .library(
            name: "yokai_no_mori",
            targets: ["yokai_no_mori"]),
    ],
    dependencies: [
        // Dependencies declare other packages that this package depends on.
        // .package(url: /* package url */, from: "1.0.0"),
    ],
    targets: [
        // Plateau :
        .target(
            name: "plateauProtocol",
            dependencies: []),
        .testTarget(
            name: "plateauTest",
            dependencies: ["plateauProtocol"]),
        // Joueur :
        .target(
            name: "joueurProtocol",
            dependencies: []),
        .testTarget(
            name: "joueurTest",
            dependencies: ["joueurProtocol"]),
        // Piece :
        .target(
            name: "pieceProtocol",
            dependencies: []),
        .testTarget(
            name: "pieceTest",
            dependencies: ["pieceProtocol"]),
        // Pieces :
        .target(
            name: "piecesProtocol",
            dependencies: []),
        .testTarget(
            name: "piecesTest",
            dependencies: ["piecesProtocol"]),
        // Face :
        .target(
            name: "faceProtocol",
            dependencies: []),
        .testTarget(
            name: "faceTest",
            dependencies: ["faceProtocol"]),
        // Reserve :
        .target(
            name: "reserveProtocol",
            dependencies: []),
        .testTarget(
            name: "reserveTest",
            dependencies: ["reserveProtocol"]),
    ]
)
